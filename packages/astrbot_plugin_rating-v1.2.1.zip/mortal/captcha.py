"""可选的 2Captcha Turnstile 接入；每次求解最多创建一个付费任务。"""
import asyncio
import ssl
import time
from urllib.parse import urlsplit

import httpx

from .reports import AnalysisError

API = "https://api.2captcha.com"


def request_failure(exc):
    """仅返回固定分类，不输出异常原文、代理密码或响应内容。"""
    cause = exc
    for _ in range(10):
        if isinstance(cause, ssl.SSLCertVerificationError):
            return 'TLS 证书校验失败，请检查系统证书和代理证书信任'
        cause = getattr(cause, '__cause__', None)
        if cause is None:
            break
    if isinstance(exc, httpx.HTTPStatusError):
        return f'接口返回 HTTP {exc.response.status_code}'
    if isinstance(exc, httpx.ProxyError):
        return '代理连接失败，请检查插件的 2Captcha HTTP 代理设置'
    if isinstance(exc, httpx.ConnectTimeout):
        return '连接 api.2captcha.com 超时，请检查网络或配置 2Captcha HTTP 代理'
    if isinstance(exc, httpx.ReadTimeout):
        return '等待 api.2captcha.com 响应超时'
    if isinstance(exc, httpx.ConnectError):
        return '无法连接 api.2captcha.com，请检查域名解析、网络和代理'
    if isinstance(exc, httpx.TimeoutException):
        return '接口请求超时'
    if isinstance(exc, ValueError):
        return '接口返回了非 JSON 或无效 JSON，可能被网关拦截'
    return '接口连接中断或协议错误'

# Install before navigation so the site's actual callback is retained. No changes
# to browser fingerprints, challenge scripts, or the site's validation rules.
TURNSTILE_CAPTURE = r"""(() => {
  let api;
  function wrap(value) {
    if (!value || !value.render || value.render.__ratingWrapped) return;
    const render = value.render;
    function wrapped(container, options) {
      const result = render.call(this, container, options);
      if (options && options.sitekey) {
        window.__ratingTurnstile = {
          sitekey: options.sitekey, action: options.action,
          data: options.cData, pagedata: options.chlPageData,
          callback: options.callback, widget: result
        };
      }
      return result;
    }
    wrapped.__ratingWrapped = true;
    value.render = wrapped;
  }
  const descriptor = Object.getOwnPropertyDescriptor(window, 'turnstile');
  if (!descriptor || descriptor.configurable) {
    api = window.turnstile;
    Object.defineProperty(window, 'turnstile', {
      configurable: true, enumerable: true,
      get: () => api, set: value => { api = value; wrap(value); }
    });
    wrap(api);
  }
})();"""


async def _pause(seconds, cancelled):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        if cancelled():
            raise AnalysisError("任务已取消；已创建的 2Captcha 任务仍可能计费。")
        await asyncio.sleep(min(.5, max(0, end - time.monotonic())))


async def solve(parameters, cancelled=lambda: False, transport=None, *, api_key, timeout=180,
                proxy=None, request_timeout=30, progress=None):
    """One paid task at most. Never retry task creation on uncertain responses."""
    key = api_key.strip()
    emit = progress or (lambda message: None)
    if not key:
        raise AnalysisError("缺少 TWOCAPTCHA_API_KEY。")
    task = {"type": "TurnstileTaskProxyless", "websiteURL": parameters["url"],
            "websiteKey": parameters["sitekey"]}
    for name in ("action", "data", "pagedata"):
        if parameters.get(name):
            task[name] = parameters[name]
    deadline = time.monotonic() + max(10, min(600, int(timeout)))
    async with httpx.AsyncClient(timeout=request_timeout, proxy=proxy or None,
                                 follow_redirects=False, transport=transport) as client:
        async def request(path, payload):
            try:
                response = await client.post(API + path, json=payload)
                response.raise_for_status()
                body = response.json()
                if not isinstance(body, dict):
                    raise ValueError()
            except (httpx.HTTPError, ValueError) as exc:
                stage = '创建任务' if path == '/createTask' else '查询结果'
                raise AnalysisError(f"2Captcha {stage}失败：{request_failure(exc)}。"
                                    "未重复创建付费任务；请先查看账户任务记录再重试。") from exc
            if body.get("errorId"):
                # Only expose documented code-like identifiers; descriptions can
                # echo request data and must never appear in saved task errors.
                code = str(body.get("errorCode", "UNKNOWN"))
                if not code.startswith("ERROR_") or not all(c.isupper() or c.isdigit() or c == "_" for c in code):
                    code = "UNKNOWN"
                raise AnalysisError(f"2Captcha 返回错误：{code}。")
            return body
        if cancelled():
            raise AnalysisError("任务已取消。")
        emit('正在连接 2Captcha 并创建验证任务')
        created = await request("/createTask", {"clientKey": key, "task": task})
        task_id = created.get("taskId")
        if not isinstance(task_id, int) or isinstance(task_id, bool) or task_id <= 0:
            raise AnalysisError("2Captcha 未返回有效任务编号；请检查账户记录，不会自动再次付费创建。")
        emit('2Captcha 已创建任务，正在等待求解')
        while time.monotonic() < deadline:
            await _pause(min(5, max(0, deadline - time.monotonic())), cancelled)
            if time.monotonic() >= deadline:
                break
            result = await request("/getTaskResult", {"clientKey": key, "taskId": task_id})
            if result.get("status") == "processing":
                continue
            if result.get("status") != "ready":
                raise AnalysisError("2Captcha 返回未知任务状态。")
            solution = result.get("solution")
            token = solution.get("token") if isinstance(solution, dict) else None
            if not isinstance(token, str) or not token:
                raise AnalysisError("2Captcha 未返回有效验证结果。")
            emit('2Captcha 已返回验证结果，交给网站验证')
            return token
    raise AnalysisError("2Captcha 等待超时；任务仍可能计费，请检查账户记录后再重试。")


async def complete(page, cancelled=lambda: False, *, solver):
    parameters = None
    for _ in range(10):
        if cancelled():
            raise AnalysisError("任务已取消。")
        parameters = await page.evaluate("""() => {
          const captured = window.__ratingTurnstile;
          if (captured && captured.sitekey && typeof captured.callback === 'function')
            return {sitekey: captured.sitekey, action: captured.action,
                    data: captured.data, pagedata: captured.pagedata, url: location.href};
          const widget = document.querySelector('form[name="reviewForm"] [data-sitekey]');
          const callback = widget && widget.dataset.callback;
          if (widget && callback && typeof window[callback] === 'function')
            return {sitekey: widget.dataset.sitekey, action: widget.dataset.action,
                    data: widget.dataset.cdata, pagedata: widget.dataset.chlPageData,
                    url: location.href};
          return null;
        }""")
        if parameters:
            break
        await _pause(1, cancelled)
    if not parameters:
        raise AnalysisError("无法取得网站 Turnstile 参数及回调；未创建付费任务。请检查站点是否使用了其他验证方式。")
    token = await solver(parameters, cancelled)
    if cancelled():
        raise AnalysisError("任务已取消；2Captcha 任务可能已经计费。")
    applied = await page.evaluate("""token => {
      const form = document.querySelector('form[name="reviewForm"]');
      if (!form) return false;
      const fields = form.querySelectorAll('[name="cf-turnstile-response"]');
      if (fields.length) fields.forEach(field => { field.value = token; });
      else {
        const field = document.createElement('input');
        field.type = 'hidden'; field.name = 'cf-turnstile-response';
        field.value = token; form.appendChild(field);
      }
      const captured = window.__ratingTurnstile;
      let callback = captured && captured.callback;
      if (typeof callback !== 'function') {
        const widget = form.querySelector('[data-sitekey][data-callback]');
        callback = widget && window[widget.dataset.callback];
      }
      if (typeof callback !== 'function') return false;
      callback(token);
      return true;
    }""", token)
    if not applied:
        raise AnalysisError("网站验证回调已变化；2Captcha 已完成，但未提交牌谱。")


class TurnstileSolver:
    def __init__(self, api_key, timeout=180, max_tasks=4, proxy='', request_timeout=30):
        if not api_key.strip():
            raise AnalysisError("已启用 2Captcha，请在插件设置填写 API Key 或设置 TWOCAPTCHA_API_KEY。")
        self._api_key = api_key.strip()
        self.timeout = max(10, min(600, int(timeout)))
        self.max_tasks = max(1, min(4, int(max_tasks)))
        self.tasks_created = 0
        self.proxy = proxy.strip()
        if self.proxy:
            try:
                url = urlsplit(self.proxy)
                valid = url.scheme in ('http', 'https') and url.hostname and url.port
            except ValueError:
                valid = False
            if not valid:
                raise AnalysisError('2Captcha HTTP 代理格式错误，请填写 http://主机:端口。')
        self.request_timeout = max(5, min(120, int(request_timeout)))
        self.progress = lambda message: None

    async def solve(self, parameters, cancelled=lambda: False):
        if self.tasks_created >= self.max_tasks:
            raise AnalysisError("本次牌谱已达到 2Captcha 付费任务上限，已停止后续分析。")
        self.tasks_created += 1
        return await solve(parameters, cancelled, api_key=self._api_key, timeout=self.timeout,
                           proxy=self.proxy, request_timeout=self.request_timeout,
                           progress=self.progress)

    async def complete(self, page, cancelled=lambda: False):
        return await complete(page, cancelled, solver=self.solve)
